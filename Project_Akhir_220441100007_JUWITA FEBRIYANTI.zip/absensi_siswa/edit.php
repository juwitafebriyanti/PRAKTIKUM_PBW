<?php
include_once("koneksi.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $result = mysqli_query($mysqli, "SELECT * FROM user WHERE id=$id");

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $nama = $row['username'];
        $kelas = $row['kelas'];
        $pass = $row['password'];
    } else {
        echo "Data tidak ditemukan.";
        exit();
    }
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $pass = $_POST['password'];

    // Update data di database
    $update = mysqli_query($mysqli, "UPDATE user SET username='$nama', kelas='$kelas', password='$pass' WHERE id=$id");

    if ($update) {
        // Redirect ke halaman utama setelah berhasil update
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($mysqli);
    }
}
?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit Data</title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">RADEN ADEBOS TUTORIAL</span>
    </div>
</nav>
<nav class="bg-success p-2 text-dark bg-opacity-10">
    <h1 class="p-4 text-center">EDIT DATA SISWA</h1>
    <div class="container">
        <form action="" method="post" name="form_edit">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="col-md-6 offset-md-3">
                <div class="mb-3">
                    <label class="form-label">Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo $nama; ?>">
                </div>
                <div class="mb-3">
                    <label for="kelas">Kelas</label>
                    <select class="form-control" name="kelas">
                        <option value="<?php echo $kelas; ?>"><?php echo $kelas; ?></option>
                        <option value="X A">X A</option>
                        <option value="X B">X B</option>
                        <option value="XI A">XI A</option>
                        <option value="XI B">XI B</option>
                        <option value="XII A">XII A</option>
                        <option value="XII B">XII B</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" class="form-control" name="password" value="<?php echo $pass; ?>">
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success" name="update">Update</button>
            </div>
        </form>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
