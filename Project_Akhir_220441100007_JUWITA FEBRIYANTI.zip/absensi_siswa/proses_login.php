<?php 
  // Memulai sesi PHP
  session_start();
  // Memasukkan file koneksi.php yang diperlukan untuk melakukan koneksi ke database. Kode ini mengasumsikan bahwa file koneksi.php berisi konfigurasi koneksi ke database.
  require_once("koneksi.php");
  // Mengambil nilai yang dikirim melalui metode POST dengan nama field 'username' dan 'password' dari form login.
  $username = $_POST['username'];
  $password = $_POST['password'];
  //  untuk mengambil data pengguna dari tabel 'user' berdasarkan username yang diinputkan.
  $sql = "SELECT * FROM user WHERE username='$username'";
  // Menjalankan query SQL menggunakan objek koneksi database $mysqli (sebelumnya didefinisikan di file koneksi.php).
  $query = $mysqli->query($sql);
  // Mengambil hasil query sebagai array asosiatif. $hasil akan berisi data pengguna yang cocok dengan username yang diinputkan.
  $hasil = $query->fetch_assoc();

  // Memeriksa apakah password yang diinputkan sama dengan password yang tersimpan di database. Jika tidak sama, maka password salah. Maka akan ditampilkan pesan kesalahan dan tautan untuk kembali ke halaman login.
  if ($query->num_rows == 0) {
    echo "<div align='center'>username belum terdaftar! <a href='login.php'>back</a></div>";
  }else{
    if ($password != $hasil['password']) {
      echo "<div align='center'>password salah! <a href='login.php'>back</a></div>";
    }else{
      // Menyimpan nilai 'level' dari pengguna yang berhasil login ke dalam variabel sesi $_SESSION['level']
      $_SESSION['level'] = $hasil['level'];
      // Menyimpan nilai 'id' dari pengguna yang berhasil login ke dalam variabel sesi $_SESSION['id_siswa']
      $_SESSION['id_siswa'] = $hasil['id'];
      // Menyimpan nilai 'username' dari pengguna yang berhasil login ke dalam variabel sesi $_SESSION['username']
      $_SESSION['username'] = $hasil['username'];
      // Mengarahkan pengguna ke halaman 'index.php' setelah berhasil login
      header('location:index.php');
    }
  }
  

 ?>