<?php
    include_once("koneksi.php");
    session_start();
    // Tambah Data
    if (isset($_POST['submit'])) {
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $pass = $_POST['pass'];
        $add = mysqli_query($mysqli, "INSERT INTO user VALUES ('','$nama', '$kelas', '$pass', 'siswa')");

        if ($add) {
            header("Location: index.php");

        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Tambah</title>
</head>
<body>
    <div class="container mt-4" >
        <form action="" method="post">
            <div class="mb-3">
                <label for="nama">Nama Lengkap</label>
                <input class="form-control" type="text" required class="form-control" name="nama" placeholder="Masukkan Nama">
            </div>
            <div class="mb-3">
                <label for="kelas">Kelas</label>
                <select class="form-control" name="kelas">
                    <option value="X A">X A</option>
                    <option value="X B">X B</option>
                    <option value="XI A">XI A</option>
                    <option value="XI B">XI B</option>
                    <option value="XII A">XII A</option>
                    <option value="XII B">XII B</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="password">Password</label>
                <input class="form-control" type="password" required class="form-control" name="pass" placeholder="Masukkan Password">
            </div>
            <div class="mb-3">
                <button name="submit" class="btn btn-success">Tambah</button> 
                <a href="index.php" class="btn btn-danger">kembali</a>    
            </div>
        </form>
    </div>
</body>
</html>