<?php
include_once("koneksi.php");
session_start();
$result = mysqli_query($mysqli, "SELECT absensi_siswa.id as absen_id,user.id, user.username as nama, user.kelas, absensi_siswa.waktu_kehadiran, absensi_siswa.keterangan FROM `absensi_siswa` JOIN user ON absensi_siswa.id_siswa = user.id");
$hasil = mysqli_query($mysqli, "SELECT * FROM user");

function sanitizeInput($input)
{
    global $mysqli;
    $input = mysqli_real_escape_string($mysqli, $input);
    $input = htmlspecialchars($input);
    return $input;
}

// Tambah Data
if (isset($_POST['submit'])) {
    $id_siswa = sanitizeInput($_POST['id_siswa']);
    $ket = sanitizeInput($_POST['keterangan']);

    // Insert data ke database
    $add = mysqli_query($mysqli, "INSERT INTO absensi_siswa(id_siswa, waktu_kehadiran, keterangan) VALUES ('$id_siswa', NOW(), '$ket')");

    if ($add) {
        // Redirect ke halaman ini agar tidak ada pengiriman ulang form saat merefresh
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        echo "Error: " . mysqli_error($mysqli);
    }
}

// Hapus Data
if (isset($_POST['delete'])) {
  $id = $_POST['id'];

  // Hapus data dari database
  $delete = mysqli_query($mysqli, "DELETE FROM absensi_siswa WHERE id=$id");

  if ($delete) {
      // Redirect ke halaman ini agar tidak ada pengiriman ulang form saat merefresh
      header("Location: " . $_SERVER['REQUEST_URI']);
      exit();
  } else {
      echo "Error: " . mysqli_error($mysqli);
  }
}

?>


<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Daftar Hadir Siswa</title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <!-- selamat datang berdasarkan username yg login -->
        <span class="navbar-brand mb-0 h1">Selamat Datang <?= $_SESSION['username'] ?></span>
        <a href="login.php" style="text-decoration:none; color:white">Logout</a>
    </div>
</nav>
<!-- jika siswa yg login maka tampilkan form di bawah ini -->
<?php if ($_SESSION['level'] == "siswa") : ?>
<nav class="bg-success p-2 text-dark bg-opacity-10">
    <h1 class="p-4 text-center">DAFTAR HADIR SISWA</h1>
    <div class="container">
        <form action="" method="post" name="form_absen">

            <div class="col-md-6 offset-md-3">
                <div class="mb-3">
                    <input type="hidden" required class="form-control" value="<?= $_SESSION['id_siswa']; ?>" name="id_siswa" placeholder="Masukkan Nama">
                </div>
                <div class="mb-3">
                    <label class="form-label" >Keterangan</label>
                    <select name="keterangan" class="form-control">
                        <option value="Masuk">Masuk</option>
                        <option value="izin">izin</option>
                        <option value="Sakit">Sakit</option>
                    </select>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success" name="submit">Hadir</button>
            </div>
        </form>

        <?php endif; ?>
<!-- jika admin yang login tampilkan form yg ada di bawah ini -->
        <!-- Form Admin -->
        <?php if ($_SESSION['level'] == "admin") : ?>
        <div class="container">
        <a href="index.php" class="btn btn-success mt-4">Kembali</a>
        <!-- Data Absensi -->
        <h2 align="center">Data Absensi</h2>
        <table class="mt-2 table table-striped">
            <tr class="table-dark">
                <th>Nama</th>
                <th>Kelas</th>
                <th>Waktu Kehadiran</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>

            <?php
            // mengambil baris data berikutnya dari hasil query yang disimpan dalam variabel $result dan menyimpannya dalam variabel $r
            while ($r = mysqli_fetch_array($result)) {
                ?>
                <tr class="table-primary">
                    <td><?php echo $r['nama']; ?></td>
                    <td><?php echo $r['kelas']; ?></td>
                    <td><?php echo $r['waktu_kehadiran']; ?></td>
                    <td><?php echo $r['keterangan']; ?></td>
                    <td>
                        <!--  display iniline blok membuat elemen tersebut memiliki tampilan yang seolah-olah berada dalam aliran konten tetapi juga memiliki kemampuan untuk mengatur lebar, tinggi, margin, dan padding sesuai dengan kebutuhan tata letak halaman. -->
                    <form action="" method="post" style="display:inline-block;"> 
                      <input type="hidden" name="id" value="<?php echo $r['absen_id']; ?>">
                      <button type="submit" class="btn btn-danger" name="delete" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
        </div>
        <?php endif; ?>
    </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
