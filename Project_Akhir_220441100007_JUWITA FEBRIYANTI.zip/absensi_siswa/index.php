<?php
//  digunakan untuk memasukkan dan menjalankan file koneksi.php dalam skrip PHP saat ini.
include_once("koneksi.php");
session_start();
// Mengambil semua data dari database
$hasil = mysqli_query($mysqli, "SELECT * FROM user");

// Fungsi untuk menghindari serangan SQL Injection
function sanitizeInput($input)
{
    // Baris ini mengacu pada variabel global $mysqli yang digunakan untuk koneksi ke database
    global $mysqli;
    // digunakan untuk melindungi input dari serangan SQL Injection dengan melakukan proses escaping karakter khusus dalam input yang dapat mempengaruhi sintaks SQL. Dalam konteks ini, $mysqli adalah objek koneksi database yang digunakan untuk menghindari karakter-karakter berbahaya dalam input yang dapat merusak query SQL.
    $input = mysqli_real_escape_string($mysqli, $input);
    // untuk melindungi input dari serangan Cross-Site Scripting (XSS) dengan mengonversi karakter-karakter khusus HTML menjadi entitas HTML yang aman.
    $input = htmlspecialchars($input);
    // mengembalikan nilai $input melalui proses pembersihian dan perlindungan
    return $input;
}

// Tambah Data
if (isset($_POST['submit'])) {
    // mengambil nilai yang dikirim melalui method post dengan nam fiel 'id_siswa' hasilnya kemudia di simpan dalam variabel $id_siswa
    // sanitizeInput() digunakan untuk membersihkan dan melindungi input dari potensi serangan SQL Injection dan Cross-Site Scripting (XSS), seperti yang dijelaskan sebelumnya.
    $id_siswa = sanitizeInput($_POST['id_siswa']);
    $ket = sanitizeInput($_POST['keterangan']);

    // Insert data ke database
    $add = mysqli_query($mysqli, "INSERT INTO absensi_siswa(id_siswa, waktu_kehadiran, keterangan) VALUES ('$id_siswa', NOW(), '$ket')");

    if ($add) {
        // Redirect ke halaman ini agar tidak ada pengiriman ulang form saat merefresh
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        echo "Error: " . mysqli_error($mysqli);
    }
}

// Hapus Data
if (isset($_POST['delete'])) {
  $id = $_POST['id'];

  // Hapus data dari database
  $delete = mysqli_query($mysqli, "DELETE FROM user WHERE id=$id");

  if ($delete) {
      // Redirect ke halaman ini agar tidak ada pengiriman ulang form saat merefresh
      header("Location: " . $_SERVER['REQUEST_URI']);
      exit();
  } else {
      echo "Error: " . mysqli_error($mysqli);
  }
}

?>


<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Daftar Hadir Siswa</title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <!-- selamat data berdasarkan username yang login -->
        <span class="navbar-brand mb-0 h1">Selamat Datang <?= $_SESSION['username'] ?></span>
        <a href="logout.php" style="text-decoration:none; color:white">Logout</a>
    </div>
</nav>
<!-- jika level yang dimasukkan itu siswa maka tampilkan form yang di bawah ini -->
<?php if ($_SESSION['level'] == "siswa") : ?>
<nav class="bg-success p-2 text-dark bg-opacity-10">
    <h1 class="p-4 text-center">DAFTAR HADIR SISWA</h1>
    <div class="container">
        <form action="" method="post" name="form_absen">

            <div class="col-md-6 offset-md-3">
                <div class="mb-3">
                    <input type="hidden" required class="form-control" value="<?= $_SESSION['id_siswa']; ?>" name="id_siswa" placeholder="Masukkan Nama">
                </div>
                <div class="mb-3">
                    <label class="form-label" >Keterangan</label>
                    <select name="keterangan" class="form-control">
                        <option value="Masuk">Masuk</option>
                        <option value="izin">izin</option>
                        <option value="Sakit">Sakit</option>
                    </select>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success" name="submit">Absen</button>
            </div>
        </form>
        <?php endif; ?>
<!-- tapi jik yang login admin tampilkan data siswa -->
        <!-- Form Admin -->
        <?php if ($_SESSION['level'] == "admin") : ?>
        <div class="container">
        <a href="tambah_siswa.php" class="btn btn-success mt-4">Tambah Siswa</a>
        <a href="data_absensi.php" class="btn btn-primary mt-4">Data Absensi</a>

        <h2 align="center">Data Siswa</h2>
        <table class="mt-2 table">
            <tr class="table-dark">
                <th>id</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr>
            <!--  -->
            <?php
                $i = 1;
                // setiap baris data akan di simpan dalam array '$r'
                while ($r = mysqli_fetch_array($hasil)) {
            ?>
            <tr class="table-primary">
                <td><?php echo $i; ?></td>
                <td><?php echo $r['username']; ?></td>
                <td><?php echo $r['kelas']; ?></td>
                <td><?php echo $r['password']; ?></td>
                <!-- untuk edit data -->
                <td>
                    <a href="edit.php?id=<?= $r['id']; ?>" class="btn btn-primary">Edit</a>
                    <form action="" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                        <!-- untuk menghapusdata -->
                        <button type="submit" class="btn btn-danger" name="delete" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <!-- meningkatkan nilai variabel $i setiap perulangan while di jalankan sehingga nomor urit pada tabel akan bertambah -->
            <?php
            $i++;
            }
            ?>
        </table>
        <!-- menutup konidisi if atu else if dalam php -->
        <?php endif; ?>
        <!--  -->
    </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
