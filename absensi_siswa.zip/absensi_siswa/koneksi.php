<?php
$dbHost = 'localhost';
$dbName = 'absensi_siswa';
$dbUsername = 'root';
$dbPassword ='';

$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

?>

