<?php
include_once("koneksi.php");
session_start();
$hasil = mysqli_query($mysqli, "SELECT * FROM user");

function sanitizeInput($input)
{
    global $mysqli;
    $input = mysqli_real_escape_string($mysqli, $input);
    $input = htmlspecialchars($input);
    return $input;
}

if (isset($_POST['submit'])) {
    $id_siswa = sanitizeInput($_POST['id_siswa']);
    $ket = sanitizeInput($_POST['keterangan']);

    $add = mysqli_query($mysqli, "INSERT INTO absensi_siswa(id_siswa, waktu_kehadiran, keterangan) VALUES ('$id_siswa', NOW(), '$ket')");

    if ($add) {
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        echo "Error: " . mysqli_error($mysqli);
    }
}

if (isset($_POST['delete'])) {
  $id = $_POST['id'];

  $delete = mysqli_query($mysqli, "DELETE FROM user WHERE id=$id");

  if ($delete) {
      header("Location: " . $_SERVER['REQUEST_URI']);
      exit();
  } else {
      echo "Error: " . mysqli_error($mysqli);
  }
}

?>


<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url(bg2.jpg);
            background-size: 100%;
        }
    </style>

    <title>Daftar Hadir Siswa</title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">Selamat Datang <?= $_SESSION['username'] ?></span>
        <a href="logout.php" style="text-decoration:none; color:white">Logout</a>
    </div>
</nav>
<?php if ($_SESSION['level'] == "siswa") : ?>
<nav class="bg-success p-2 text-dark bg-opacity-10">
    <h1 class="p-4 text-center">DAFTAR HADIR SISWA</h1>
    <div class="container">
        <form action="" method="post" name="form_absen">

            <div class="col-md-6 offset-md-3">
                <div class="mb-3">
                    <input type="hidden" required class="form-control" value="<?= $_SESSION['id_siswa']; ?>" name="id_siswa" placeholder="Masukkan Nama">
                </div>
                <div class="mb-3">
                    <label class="form-label" >Keterangan</label>
                    <select name="keterangan" class="form-control">
                        <option value="Masuk">Masuk</option>
                        <option value="izin">izin</option>
                        <option value="Sakit">Sakit</option>
                    </select>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success" name="submit">Absen</button>
            </div>
        </form>
        <?php endif; ?>
        <?php if ($_SESSION['level'] == "admin") : ?>
        <div class="container">
        <a href="tambah_siswa.php" class="btn btn-success mt-4">Tambah Siswa</a>
        <a href="data_absensi.php" class="btn btn-primary mt-4">Data Absensi</a>

        <h2 align="center">Data Siswa</h2>
        <table class="mt-2 table">
            <tr class="table-dark">
                <th>No</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr>
            <?php
                $i = 1;
                while ($r = mysqli_fetch_array($hasil)) {
            ?>
            <tr class="table-primary">
                <td><?php echo $i; ?></td>
                <td><?php echo $r['username']; ?></td>
                <td><?php echo $r['kelas']; ?></td>
                <td><?php echo $r['password']; ?></td>
                <td>
                    <a href="edit.php?id=<?= $r['id']; ?>" class="btn btn-primary">Edit</a>
                    <form action="" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                        <button type="submit" class="btn btn-danger" name="delete" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php
            $i++;
            }
            ?>
        </table>
        <?php endif; ?>
    </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
